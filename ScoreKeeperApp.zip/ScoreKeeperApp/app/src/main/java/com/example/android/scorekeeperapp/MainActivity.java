package com.example.android.scorekeeperapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    int teamARuns=0;
    int teamAwicket=0;
    int teamAextras=0;
    int teamBRuns=0;
    int teamBwicket=0;
    int teamBextras=0;


    public void runs6A(View view)
 {
     teamARuns=teamARuns+6;
     ARuns(teamARuns);
 }
 public void runs4A(View view)
 {
     teamARuns=teamARuns+4;
     ARuns(teamARuns);
 }
 public void wicketsA(View view)
 {
     teamAwicket=teamAwicket+1;
     AWickets(teamAwicket);
 }
public void extrasA(View view)
    {
        teamAextras=teamAextras+1;
        AExtras(teamAextras);
    }
    public void ARuns(int score) {
        TextView scoreView = (TextView) findViewById(R.id.teamA_runs);
        scoreView.setText(String.valueOf(score));
    }
    public void AWickets(int score) {
        TextView scoreView = (TextView) findViewById(R.id.teamA_wickets);
        scoreView.setText(String.valueOf(score));
    }
    public void AExtras(int score)
    {
        TextView scoreView = (TextView) findViewById(R.id.teamA_extras);
        scoreView.setText(String.valueOf(score));
    }

    public void runs6B(View view)
    {
        teamBRuns=teamBRuns+6;
        BRuns(teamBRuns);
    }
    public void runs4B(View view)
    {
        teamBRuns=teamBRuns+4;
        BRuns(teamBRuns);
    }
    public void wicketsB(View view)
    {
        teamBwicket=teamBwicket+1;
        BWickets(teamBwicket);
    }
    public void extrasB(View view)
    {
        teamBextras=teamBextras+1;
        BExtras(teamBextras);
    }
    public void BRuns(int score) {
        TextView scoreView = (TextView) findViewById(R.id.teamB_runs);
        scoreView.setText(String.valueOf(score));
    }
    public void BWickets(int score) {
        TextView scoreView = (TextView) findViewById(R.id.teamB_wickets);
        scoreView.setText(String.valueOf(score));
    }
    public void BExtras(int score)
    {
        TextView scoreView = (TextView) findViewById(R.id.teamB_extras);
        scoreView.setText(String.valueOf(score));
    }
public void reset(View view)
{
     teamARuns=0;
     teamAwicket=0;
     teamAextras=0;
     teamBRuns=0;
     teamBwicket=0;
     teamBextras=0;
    ARuns(teamARuns);
    BRuns(teamBRuns);
    AWickets(teamAwicket);
    BWickets(teamBwicket);
    AExtras(teamAextras);
    BExtras(teamBextras);

}

}

